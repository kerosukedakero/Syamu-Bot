python3 main.py tweetsdata
